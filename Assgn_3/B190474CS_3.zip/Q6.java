import studentdataextended.StudentDataExtended;
import java.util.*;
class Q6{
    public static void main(String[] args){
        StudentDataExtended obj = new StudentDataExtended();
        obj.addDetails();
        obj.printDetails();
    }
}