import java.util.*;
class Number{
    
}
class Q4{

}